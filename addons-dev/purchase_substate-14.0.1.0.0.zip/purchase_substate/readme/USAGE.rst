#. Go to ** Settings > Technical > Database Structure ** and Add  "Base substate".
    If necessery you can add "target State values" (ex define a substate for "cancel"
    state).
    Substate sequence is very important.
#. Create a purchae order and check if the substate are displayed on the header of
   form view. Check if you can't set substate defined for purchase if sate is a RFQ.
