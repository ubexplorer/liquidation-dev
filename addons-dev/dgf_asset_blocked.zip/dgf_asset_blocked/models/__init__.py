from . import dgf_base_type
from . import asset_blocked_list
from . import asset_blocked_list_item
from . import asset_blocked_request
from . import asset_blocked_request_item
from . import asset_blocked_subject
from . import asset_blocked_document
from . import dgf_document_blocked
from . import asset_blocked_agreement
from . import res_company
from . import res_country
from . import mail_activity
# from . import ir_attachment
