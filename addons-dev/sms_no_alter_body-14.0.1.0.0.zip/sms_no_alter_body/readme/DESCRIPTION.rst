Skipping the formatting of sms between html and text by using the original "body" of messages.
For exemple, this module cancels the duplicate URL at the sms's end.
