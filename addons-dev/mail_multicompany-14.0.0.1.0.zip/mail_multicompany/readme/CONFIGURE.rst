* Go to 'Settings / Technical / Outgoing Mail Servers', and add the company.
