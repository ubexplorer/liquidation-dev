To use this module, you need to:

* Send some email or message that comes out of Odoo.
