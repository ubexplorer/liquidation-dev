* Jesús Ventosinos Mayor <jesus@comunitea.com>
* Cédric Pigeon <cedric.pigeon@acsone.eu>
* Valentin Vinagre <valentin.vinagre@sygel.es>
