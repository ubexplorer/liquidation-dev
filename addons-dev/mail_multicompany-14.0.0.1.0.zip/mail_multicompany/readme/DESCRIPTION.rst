This module adds company_id to the models ir.mail_server and mail.message. Also inherits mail.message create function to set the company mail_server.
