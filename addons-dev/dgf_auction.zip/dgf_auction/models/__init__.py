# -*- coding: utf-8 -*-

from . import dgf_auction
from . import dgf_auction_category
from . import prozorro_api
from . import dgf_auction_lot
from . import dgf_auction_award
from . import procedure_contract
from . import stat_classifier
from . import res_config_settings
from . import res_partner
# from . import dgf_auction_lot_asset
