NBU connector
============================

Implements base connection to NBU API

This module is developed by the `KitWorks <https://kitworks.systems/>`__.

