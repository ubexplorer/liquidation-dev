{
    'name': 'NBU connector',

    'author': 'Kitworks Systems',
    'website': 'https://kitworks.systems/',

    'category': 'Accounting',
    'license': 'OPL-1',
    'version': '16.0.1.0.1',

    'depends': ['base', ],

    'images': [
        'static/description/cover.png',
        'static/description/icon.png',
    ],

    'price': 0,
    'currency': 'EUR',

    'live_test_url': 'https://kw-currency-nbu.demo13.kitworks.systems',

}
