import logging

from odoo import models

from ..connector import NbuApi

_logger = logging.getLogger(__name__)


class NbuConnectortMixin(models.AbstractModel):
    _name = 'kw.nbu.connector.mixin'
    _description = 'NBU connector mixin '

    @staticmethod
    def kw_nbu_get_connector():
        return NbuApi()
