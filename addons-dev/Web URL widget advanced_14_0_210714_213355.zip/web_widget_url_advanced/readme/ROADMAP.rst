* ``<field text_field="foo"/>`` is not supported in tree views.
