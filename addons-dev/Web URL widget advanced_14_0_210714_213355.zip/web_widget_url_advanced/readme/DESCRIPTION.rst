Extend URL widget features to ease customization of anchor's text.

By default, the URL widget will show the plain URL.
You can specify an attribute to provide a static label too.

With this module, you can use a field for link's inner text using attribute
'text_field'. You can also add a prefix to the link using attribute
'prefix_name'.

Until 13.0 this functionality was separated in modules 'web_widget_url_advanced'
and 'web_widget_prefixed_url'
