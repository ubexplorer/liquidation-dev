Task type
=========================

Adds type to project tasks

This module is developed by the `KitWorks <https://kitworks.systems/>`__.
