import logging

from odoo import models, fields

_logger = logging.getLogger(__name__)


class TaskType(models.Model):
    _name = 'kw.task.type'
    _description = 'Task type'
    _order = 'name'

    name = fields.Char(
        required=True, )


class ProjectTask(models.Model):
    _inherit = 'project.task'

    kw_type_id = fields.Many2one(
        comodel_name='kw.task.type', string='Type', )
