This module extends module ir_sequence_option and allow you to
provide optional sequences for account.move documents, i.e., invoice, bill, journal entry.
