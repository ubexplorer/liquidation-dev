* Stefan Rijnhart <stefan@opener.amsterdam>
* Holger Brunn <hbrunn@therp.nl>
* Stéphane Mangin <stephane.mangin@camptocamp.com>
