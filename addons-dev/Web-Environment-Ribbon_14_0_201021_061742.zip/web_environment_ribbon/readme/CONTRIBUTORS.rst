* Francesco Apruzzese <cescoap@gmail.com>
* Javi Melendez <javimelex@gmail.com>
* Antonio Espinosa <antonio.espinosa@tecnativa.com>
* Thomas Binsfeld <thomas.binsfeld@acsone.eu>
* Xavier Jiménez <xavier.jimenez@qubiq.es>
* Dennis Sluijk <d.sluijk@onestein.nl>
* Eric Lembregts <eric@lembregts.eu>
