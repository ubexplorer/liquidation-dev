# -*- coding: utf-8 -*-

from . import dgf_asset
from . import dgf_asset_loan
from . import dgf_asset_sms
from . import dgf_asset_realty
# from . import dgf_company_partner
# from . import res_partner
# from . import stat_classifier_item
# from . import res_config_settings
