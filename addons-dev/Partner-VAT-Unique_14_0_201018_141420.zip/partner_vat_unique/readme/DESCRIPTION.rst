Module to make the VAT number unique for customers and suppliers. Will not
consider empty VATs as duplicated.
