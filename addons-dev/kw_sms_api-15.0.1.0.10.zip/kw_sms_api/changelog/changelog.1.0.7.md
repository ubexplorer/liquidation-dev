Init changelog
-bugfix | send message viber

