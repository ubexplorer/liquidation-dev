Init changelog
-bugfix | send message viber
-bugfix | widget phone

