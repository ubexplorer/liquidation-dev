Init changelog
-bugfix | note crm lea

