from . import (
    res_partner,
    sms_api,
    sms_sms,
    sms_log,
    sms_provider,
)
