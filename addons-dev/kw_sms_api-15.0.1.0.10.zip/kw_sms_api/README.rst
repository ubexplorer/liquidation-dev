SMS API
======================

This module overwrite odoo sms module, inherit sms.sms model for using
local provider gates. Implements provider gateway connector installing.

Logging sms sends. Implements SandBox provider for testing sms without
connecting to gates and sending real sms.

This module is developed by the `KitWorks <https://kitworks.systems/>`__.

