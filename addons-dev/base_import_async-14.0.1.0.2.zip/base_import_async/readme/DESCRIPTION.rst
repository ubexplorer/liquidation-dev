This module extends the standard CSV import functionality
to import files in the background using the OCA/queue
framework.
