Sébastien Beau (Akretion) authored the initial prototype.

Stéphane Bidoul (ACSONE) extended it to version 1.0 to support
multi-line records, store data to import as attachments
and let the user control the asynchronous behaviour.

Other contributors include:

* Anthony Muschang (ACSONE)
* David Béal (Akretion)
* Jonathan Nemry (ACSONE)
* Laurent Mignon (ACSONE)
* Dennis Sluijk (Onestein)
* Guewen Baconnier (Camptocamp)
