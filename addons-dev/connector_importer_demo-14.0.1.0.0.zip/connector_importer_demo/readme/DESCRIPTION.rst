Demo module for Connector Importer.
