This module allows to import / update records from files using the connector
framework (i.e. mappers) and job queues.
