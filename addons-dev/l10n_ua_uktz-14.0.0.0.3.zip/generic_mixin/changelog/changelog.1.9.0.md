Added new mixin `generic.mixin.data.updatable`, that provides new fields
that describes corresponding `ir.model.data` records
