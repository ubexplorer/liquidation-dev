Added new mixin `generic.mixin.name.by.sequence` that could be used to
automatically add `name` field to model and automatically generate name based on
specified sequence. Useful for cases, when you have to create custom model like Sale Order, etc.
