SMS Marketing API
======================

This module overwrite sms marketing for sending sms through local
provider gate.

This module is developed by the `KitWorks <https://kitworks.systems/>`__.

