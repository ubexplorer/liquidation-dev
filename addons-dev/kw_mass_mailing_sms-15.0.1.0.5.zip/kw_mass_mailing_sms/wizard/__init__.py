from . import mailing_sms_test
