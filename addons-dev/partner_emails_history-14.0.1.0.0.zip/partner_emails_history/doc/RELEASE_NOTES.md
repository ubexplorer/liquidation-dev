## Module <partner_emails_history>

#### 09.10.2020
#### Version 14.0.1.0.0
#### ADD
- Initial Commit for partner_emails_history
