To install this module, you need to:

#. Just install it.
