Address
======================

It provide functionality for typed address management used in post
office services, courier routes, replace address in contacts etc.

This module is developed by the `KitWorks <https://kitworks.systems/>`__.
