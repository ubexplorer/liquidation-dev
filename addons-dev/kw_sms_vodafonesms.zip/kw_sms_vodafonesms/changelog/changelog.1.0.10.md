Init changelog
-bugfix | widget phone

