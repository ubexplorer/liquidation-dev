# Changelog

## Version 1.0.10

Init changelog
-bugfix | widget phone



## Version 1.0.9

Init changelog
-bugfix | note crm lea



## Version 1.0.8

Init changelog
-bugfix | send message viber
-bugfix | widget phone



## Version 1.0.7

Init changelog
-bugfix | send message viber



## Version 1.0.3

Init changelog



