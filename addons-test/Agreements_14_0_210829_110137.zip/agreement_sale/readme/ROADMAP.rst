Features to evaluate before implementation

* add smart button on agreement to access implied sales
* add module agreement_account: agreement_sale'll depends on it
