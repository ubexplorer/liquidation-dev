# License LGPLv3.0 or later (https://www.gnu.org/licenses/lgpl-3.0.en.html).

from . import test_agreement
from . import test_agreement_appendix
from . import test_agreement_clause
from . import test_agreement_line
from . import test_agreement_recital
from . import test_agreement_section
from . import test_create_agreement_wizard
