This module extends address field with staircase.
Update country street format with the  following:
%(street_name)s Bl. %(street_number)s Sc. %(street_staircase)s Ap. %(street_number2)s
