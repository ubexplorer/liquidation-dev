from . import l10n_ro_mixin
from . import account_journal
from . import product_template
from . import res_partner
from . import res_company
from . import res_config_settings
from . import res_bank
from . import ir_ui_menu
