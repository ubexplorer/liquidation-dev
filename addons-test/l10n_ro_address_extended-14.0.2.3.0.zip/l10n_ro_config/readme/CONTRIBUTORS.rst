* `NextERP Romania <https://www.nexterp.ro>`_:

  * Fekete Mihai <feketemihai@nexterp.ro>

* `Terrabit <https://www.terrabit.ro>`_:

  * Dorin Hongu <dhongu@gmail.com>

* Adrian Vasile <adrian.vasile@gmail.com>

Do not contact contributors directly about support or help with technical issues.
