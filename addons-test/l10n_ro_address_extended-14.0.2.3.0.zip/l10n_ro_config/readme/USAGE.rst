Companies
=========

- You can complete dedicated fields for Romanian companies, like "Share Capital", "CAEN Code".
- From Romanian page from Configuration, you can define new properties for your company, depending on the modules that you have installed.

Partners
=========

- You can complete dedicated fields for Romanian partners, like "VAT Subjected", "CAEN Code", "E-invoicing".
- You can input also partners without VAT country code, but you need to select also the country.

Products
========

- Use different taxes for "Service" products, they are defined in the Chart of Accounts, but here we set up the default taxes used.

Bank Accounts
=============

- Tick the "Ro Print in Report" fields if you want the bank account to be printed in reports (not all reports are updated but you can use the example from the Invoice Report to change the other report where you want to print the bank accounts).

  ** This applies also for company bank accounts, there you can use also the related field from Account Journal to mark them.
