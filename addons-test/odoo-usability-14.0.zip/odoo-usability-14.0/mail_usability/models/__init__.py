from . import res_partner
from . import mail_activity
from . import mail_template
