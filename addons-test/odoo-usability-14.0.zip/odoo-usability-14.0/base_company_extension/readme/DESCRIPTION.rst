This module adds the following fields to the ResCompany model:
* Capital Amount
* Legal Type

This is useful to display the legal name of the company in reports
