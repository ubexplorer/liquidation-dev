from . import intrastat_product_type
