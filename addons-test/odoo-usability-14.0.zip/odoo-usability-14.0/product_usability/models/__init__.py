from . import product_product
from . import product_template
from . import product_supplierinfo
from . import product_pricelist
from . import product_category
from . import product_attribute
