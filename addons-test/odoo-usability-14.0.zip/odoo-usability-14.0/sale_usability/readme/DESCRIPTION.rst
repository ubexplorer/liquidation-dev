This modules adds the following functions:

* Display amount untaxed in tree view
* Add sale_ids and sale_count on Invoice
* Methods for py3o sale reports
* Add tracking on partner warning fields
* Add tracking on product fields
* Add tracking on Sale Order fields
* Add menu for Pricelist Items
* Add `has_discount` field on Sale Order
* Restore drill-through on sale and invoice reports
* Move client_order_ref from the second tab to the top
* Protect Cancel button with a confirmation pop-up
* Remove Sale Orders from Quotations menu
* Add Group By Customer on Sales order search view
* Add sum=1 on several quantity fields
* Add Product Category Menu entry
