from . import partner_phone
from .post_install import migrate_to_partner_phone
