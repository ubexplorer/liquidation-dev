from . import product
from . import pos_category
from . import pos_config
from . import pos_payment_method
