This module adds the following functions:
 - Track visibility on partner and product purchase warning
 - Track visibility on Purchase Order warning
 - Methods to help generate py3o purchase reports
 - Use untaxed amount in name_get of purchase orders
 - Protect Cancel button with a confirmation pop-up
 - Misc. improvements to Purchase Order Line views
