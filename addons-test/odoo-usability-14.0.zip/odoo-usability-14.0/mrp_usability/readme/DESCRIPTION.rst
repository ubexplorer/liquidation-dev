Small usability improvements on MRP:

* order by id desc

* show field date_start and date_finished on mrp.production form view

* show more fields on stock move form

* show bom type in tree view + add group by

* complete Manufacturing Order report with unvailable products

* improve smart button from products to BoMs (display BoM form if only one instead of displaying a list of one)
