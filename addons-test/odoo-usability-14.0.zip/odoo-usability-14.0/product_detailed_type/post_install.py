# Copyright 2023 Akretion France (http://www.akretion.com/)
# @author: Alexis de Lattre <alexis.delattre@akretion.com>
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).


def set_product_detailed_type(cr, registry):
    cr.execute('UPDATE product_template SET detailed_type=type')
