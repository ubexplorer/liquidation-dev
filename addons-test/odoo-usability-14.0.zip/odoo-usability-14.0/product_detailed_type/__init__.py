from . import models
from .post_install import set_product_detailed_type
