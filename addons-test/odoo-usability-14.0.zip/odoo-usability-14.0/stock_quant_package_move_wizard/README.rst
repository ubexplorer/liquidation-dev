Module Stock Quant Package Moving Wizard
=========================================

This module provides a **super fast** and **super easy** way of moving a quant to another stock location.

Usage
=====

1. Select one or several quants
2. Click on the *Move* button
3. Follow the instructions on the wizard: select a picking type (or a destination stock location) and, if you don't want to move the full quant, edit the quantity to move.
4. Validate the wizard

Contributors
============

* Alexis de Lattre <alexis.delattre@akretion.com>
* Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>
* Pedro M. Baeza <pedro.baeza@serviciosbaeza.com>
* Ana Juaristi <ajuaristio@gmail.com>
