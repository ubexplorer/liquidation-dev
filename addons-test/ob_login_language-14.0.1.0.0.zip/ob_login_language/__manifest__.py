# -*- coding: utf-8 -*-
{
    'name': "Login Language",

    'summary': """
        Language Selector in Login Page.""",

    'description': """
        User Login Language, Login Language, login, login in odoo 14, language, 
        custom language, sale report, custom report, language selector, odoo,
        odoobeing, odoo14.""",

    'author': "Odoo Being",
    'website': "https://www.odoobeing.com",
    'license': 'LGPL-3',
    'category': 'Tools',
    'version': '14.0.1.0.0',
    'support': 'odoobeing@gmail.com',
    'images': ['static/description/images/login_language_selection.png'],
    'installable': True,
    'auto_install': False,
    'depends': ['base'],
    'data': [
        'views/templates.xml',
    ],
}
