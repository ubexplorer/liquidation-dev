Address partner
========================

Adds partner (contact) to address

This module is developed by the `KitWorks <https://kitworks.systems/>`__.

