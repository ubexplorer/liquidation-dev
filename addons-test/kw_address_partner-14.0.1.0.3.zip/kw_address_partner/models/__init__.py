from . import (
    address,
    res_partner,
)
