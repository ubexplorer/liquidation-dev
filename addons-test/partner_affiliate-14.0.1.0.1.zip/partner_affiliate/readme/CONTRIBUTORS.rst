* Yannick Vaucher <yannick.vaucher@camptocamp.com>
* Vicent Cubells <vicent.cubells@tecnativa.com>
* Raul Martin <raul.martin@braintec-group.com>
* Dave Lasley <dave@laslabs.com>
* Dennis Sluijk <d.sluijk@onestein.nl>
* Stephan Rozendaal <stephan.rozendaal@neobis.net>
* Achraf Mhadhbi <machraf@bloopark.de>
