You can find the new field on the partner (contact, customer, etc) form.
