Adds a sequence field to maintenance teams. Maintenance requests will follow
the sequence of its team.
