Huge test log data will be placed to file
