Add cover.png and description
