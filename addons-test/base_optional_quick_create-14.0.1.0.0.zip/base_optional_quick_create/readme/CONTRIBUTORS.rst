* Jonathan Nemry jonathan.nemry@acsone.eu
* Lorenzo Battistini lorenzo.battistini@agilebg.com
* Alexis de Lattre alexis.delattre@akretion.com
* Gilles Meyomesse gilles.meyomesse@acsone.eu (https://acsone.eu)
* Carmen Rondon Regalado crondon@archeti.com
