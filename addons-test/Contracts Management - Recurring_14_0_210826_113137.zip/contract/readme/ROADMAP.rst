* Recover states and others functional fields in Contracts.
* Add recurrence flag at template level.
