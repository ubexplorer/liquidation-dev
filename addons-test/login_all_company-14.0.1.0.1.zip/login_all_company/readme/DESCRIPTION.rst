This module will make accessible all companies by default on first login.
Once the user has applied some changes, it will be kept as it is.
