compatible with crnd_account_partner_requisites
===============================================
