* Stéphane Bidoul <stephane.bidoul@acsone.eu>
* Yannick Vaucher <yannick.vaucher@camptocamp.com>
* Alexandre Fayolle <alexandre.fayolle@camptocamp.com>
* Holger Brunn <hbrunn@therp.nl>
* Laurent Mignon (aka lmi) <laurent.mignon@acsone.eu>
* Sandy Carter <sandy.carter@savoirfairelinux.com>
* Fabio Vilchez <fabio.vilchez@clearcorp.co.cr>
* Jos De Graeve <Jos.DeGraeve@apertoso.be>
* Lai Tim Siu (Quaritle Limited) <info@quartile.co>
* Tharathip Chaweewongphan <tharathipc@ecosoft.co.th>
* Eric Antones <eantones@nuobit.com>
