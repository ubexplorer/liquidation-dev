{
    'name': 'Mixins',
    'version': '14.0.1.0.3',

    'author': 'Kitworks Systems',
    'website': 'https://kitworks.systems/',
    'license': 'OPL-1',
    'category': 'Extra Tools',

    'depends': ['base', ],
    'data': [],
    'demo': [],

    'images': [
        'static/description/cover.png',
        'static/description/icon.png',
    ],
}
