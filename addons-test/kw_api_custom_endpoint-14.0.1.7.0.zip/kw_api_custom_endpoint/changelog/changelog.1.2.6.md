Add fields to endpoint tree
