Fix write_date field required
