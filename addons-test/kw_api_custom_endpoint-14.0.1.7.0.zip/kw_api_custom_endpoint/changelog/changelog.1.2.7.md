Fix M2O and Integer searching domain
