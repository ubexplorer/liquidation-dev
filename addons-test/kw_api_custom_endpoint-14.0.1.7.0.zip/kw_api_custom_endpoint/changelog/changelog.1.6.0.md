adds html2text to evel context
