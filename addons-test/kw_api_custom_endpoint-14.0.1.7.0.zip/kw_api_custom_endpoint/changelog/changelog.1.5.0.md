Added an option for m2x fields to specify the field in which the search takes place
