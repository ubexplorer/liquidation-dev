Adds relational fields display selection 
Fix timezone bug
