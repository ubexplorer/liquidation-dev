The functionality of choosing a response time zone for a specific endpoint has been added
