add cover.png
