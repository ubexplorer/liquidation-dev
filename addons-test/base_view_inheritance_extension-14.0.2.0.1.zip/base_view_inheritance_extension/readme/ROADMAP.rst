* On `15.0`, remove `list_add` and `list_remove` fetures.
* Support an ``eval`` attribute for our new node types.
