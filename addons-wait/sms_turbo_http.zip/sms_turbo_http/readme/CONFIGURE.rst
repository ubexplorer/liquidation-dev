To configure this module, you need to:

* Go to settings > technical > IAP Account
* Create a new account with **SMS OVH HTTP** as provider
* Fill your account information as follows:
    * SMS Account

      .. figure:: ../static/img/img.png
         :width: 800 px

    * API User ID / API User Password

      .. figure:: ../static/img/img_1.png
         :width: 800 px

    * Sender name

      .. figure:: ../static/img/img_2.png
         :width: 800 px

    * You can now send an sms!
