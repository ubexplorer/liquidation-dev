Every user without *Direct Export (xlsx)* permission won't have the option available.
