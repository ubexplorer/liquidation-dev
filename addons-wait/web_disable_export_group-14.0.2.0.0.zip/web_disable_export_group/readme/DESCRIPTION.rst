The standard export group prevents both options: 'Direct Export (xlsx)' and 'Export All'.

This module adds a new group for the 'Direct Export (xlsx)' feature, leaving the standard one for only the 'Export All' feature.

Admin user can always use the export option.
