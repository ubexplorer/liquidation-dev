==================
Base Synchro
==================

* This module let you to synchronize more than 1 databases.

* There is menu called 'Server to be synchronized' it will help you to configure servers.

* 'Synchronized objects' will help you to select object which objects you want to syncronize in another database

* There is menu 'Fields Not Sync' you can use that to not synchronize any particular object.

* Trigger synchronization with its database objects

Usage
=====
How to use it:

* Run Server in terminal load updated app list select Base Synchro module and installed it.
* Make sure to apply --db-filter="db_name" in your path when running the server locally in the system.
* See menu called Server to be synchronized configure server and after configuration click on button Synchronize
* and check database is synchronized successfully.
* It will able to synchronize models such as users, contacts, partner category,sales order, sales order line, products,product pricelist, purchase order,purchase order line.


Bug Tracker
===========

Credits
=======
