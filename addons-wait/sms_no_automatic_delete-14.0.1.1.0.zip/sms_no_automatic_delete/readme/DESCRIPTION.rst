This module allows to save sent sms and to delete them after a delay (in days).
In addition, the sms state is update as "sent" when they are sent and saved.
