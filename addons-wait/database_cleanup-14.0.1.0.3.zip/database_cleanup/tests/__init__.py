# Copyright 2016 Therp BV <http://therp.nl>
# Copyright 2021 Camptocamp
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).
from . import common
from . import test_create_indexes
from . import test_identifier_adapter
from . import test_purge_columns
from . import test_purge_data
from . import test_purge_menus
from . import test_purge_models
from . import test_purge_modules
from . import test_purge_properties
from . import test_purge_tables
