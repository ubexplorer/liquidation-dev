# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).
from . import test_partner_relation_common
from . import test_partner_relation_action
from . import test_partner_relation
from . import test_partner_relation_all
from . import test_partner_search
