* Holger Brunn <hbrunn@therp.nl>
* Stefan Rijnhart <stefan@therp.nl>
* Ronald Portier <ronald@therp.nl>
* Sandy Carter <sandy.carter@savoirfairelinux.com>
* Bruno Joliveau <bruno.joliveau@savoirfairelinux.com>
* Adriana Ierfino <adriana.ierfino@savoirfairelinux.com>
* Numigi (tm) and all its contributors (https://bit.ly/numigiens)
* Radovan Skolnik <radovan@skolnik.info>, KEMA SK s.r.o. (https://www.kema.sk)
* `DynApps NV <https://www.dynapps.be>`_:

  * Raf Ven
