* Go to Attachments, and set categories as tags.
