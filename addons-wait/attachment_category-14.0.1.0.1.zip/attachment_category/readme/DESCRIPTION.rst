This module adds a document category to help classification.
