# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models


class WizRequestAgreement(models.TransientModel):
    _name = "wiz.request.agreement"
    _description = "Створення договору"

    @api.model
    def _selection_relaion_type(self):
        return [
            ("full", "Майно із заявки повністю"),
            ("partial", "Майно із заявки частково"),
        ]

    # @api.model
    # def default_get(self, fields):
    #     result = super(DocTemplatePreview, self).default_get(fields)
    #     doc_template_id = self.env.context.get('default_doc_template_id')
    #     if not doc_template_id or 'resource_ref' not in fields:
    #         return result
    #     doc_template = self.env['doc.template'].browse(doc_template_id)
    #     res = self.env[doc_template.model_id.model].search([], limit=1)
    #     if res:
    #         result['resource_ref'] = '%s,%s' % (doc_template.model_id.model, res.id)
    #     return result

    # doc_template_id = fields.Many2one('doc.template', required=True, ondelete='cascade')


    request_type = fields.Many2one(string='Тип заявки', related="request_id.type_id", readonly=True)
    request_id = fields.Many2one('asset.blocked.request', string="Завка", readonly=True)
    company_id = fields.Many2one("res.company", string="Банк", default=lambda self: self.env.company)
    subject_id = fields.Many2one('asset.blocked.subject', string="Контрагент", ondelete='restrict', index=True)

    # agreement_id = fields.Many2one('asset.blocked.agreement', string="Договір", ondelete='cascade')
    relaion_type = fields.Selection(_selection_relaion_type, string='Як визначити майно?')
    # подумати як перекинути майно з заявки в договір: повністю частково
    # asset_blocked_ids = fields.Many2many(string="Майно", comodel_name='asset.blocked.list.item', inverse_name='agreement_id')
    asset_blocked_ids = fields.Many2many(
        comodel_name='asset.blocked.list.item',
        string='Заявки',
        domain="[('request_id', '=', request_id)]")


    def action_update(self):
        self.ensure_one()
        self.action_create_agreement()
        # return {"type": "ir.actions.act_window_close"}

    def action_create_agreement(self):
        self.ensure_one()

        return {
            'name': 'Договори',
            'view_type': 'form',
            'res_model': 'asset.blocked.agreement',
            'view_id': False,
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_request_ids': [self.id],
                'default_company_id': self.company_id.id,
                'default_subject_id': self.subject_id.id,
                'default_asset_blocked_ids': self.asset_blocked_ids.ids},
            'type': 'ir.actions.act_window'
        }