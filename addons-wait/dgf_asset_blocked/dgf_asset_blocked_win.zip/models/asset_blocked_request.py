# -*- coding: utf-8 -*-

import ast

from datetime import date, datetime, timedelta
import base64

from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT


class AssetBlockedRequest(models.Model):
    _name = 'asset.blocked.request'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'base.stage.abstract', 'base.type.abstract']
    _description = 'Заявка щодо майна блокованого'
    is_base_stage = True
    is_base_type = True
    _order = "code desc"
    _rec_name = "code"
    _check_company_auto = True

    name = fields.Char(string='Найменування', compute='_compute_name', store=True, index=True)
    code = fields.Char(string='Код', readonly=True, copy=False)  # sequence
    company_id = fields.Many2one('res.company', string='Банк', required=True)
    subject_id = fields.Many2one('asset.blocked.subject', string="Ініціатор", index=True)
    # blocked_document_ids = fields.One2many('asset.blocked.document', 'parent_id', string="Похідні документи", index=True)  # ondelete='restrict',
    blocked_document_ids = fields.Many2many('asset.blocked.document', string='Документи щодо передання', domain="[('subject_id', '=', subject_id), ('state', '=', 'draft')]")
    request_date = fields.Date('Дата заявки банку', tracking=False)
    request_number = fields.Char('Номер заявки банку', tracking=False)
    asset_blocked_list_id = fields.Many2one('asset.blocked.list', string="Перелік майна", ondelete='restrict', required=True, index=True, check_company=True)
    document_id = fields.Many2one('dgf.document.blocked', string="Рішення про затвердження", ondelete='restrict', index=True)  # domain="[('partner_ids', 'in', company_id.partner_id)]"
    close_date = fields.Date('Фактична дата виконання')
    aquirer_id = fields.Many2one('asset.blocked.subject', string="Отримувач", index=True)
    transfer_date = fields.Date(string='Дата передання')

    description = fields.Text('Опис')
    memo = fields.Char(string='Примітки')
    # document_text = fields.Text('Текст документа')
    document_text = fields.Html('Текст документа', sanitize=False)
    document_letters = fields.Char(string='Реквізити звернення')
    document_reasons = fields.Char(string='Реквізити документів-підстав')
    document_transfers = fields.Char(string='Реквізити документів про передання')

    asset_blocked_ids = fields.One2many(string="Майно у заявці на включення", comodel_name='asset.blocked.list.item', inverse_name='request_id', index=True)
    asset_blocked_exclude_ids = fields.One2many(string="Майно у заявці на виключення", comodel_name='asset.blocked.request.item', inverse_name='request_id', index=True)
    type_id = fields.Many2one(string='Тип заявки', required=False)  # required=True after initial import
    type_code = fields.Char(string='Код типу заявки', related="type_id.code", readonly=True)
    stage_id = fields.Many2one(string='Статус')
    stage_code = fields.Char(string='Код статусу', related="stage_id.code", readonly=True)
    active = fields.Boolean(string='Активно', default=True)
    server_in_request = fields.Boolean(string='В заявці є сервери')  # add compute='_compute_servers',
    # done = fields.Boolean(string='Виконано', related='stage_id.done')
    user_id = fields.Many2one('res.users', string='Виконавець', default=lambda self: self.env.user, tracking=True)
    # maintenance_team_id = fields.Many2one('maintenance.team', string='Team', required=True, default=_get_default_team_id, check_company=True)
    # owner_user_id = fields.Many2one('res.users', string='Created by User', default=lambda s: s.env.uid)
    
    # item_count = fields.Integer(string="Майна всього", compute='_compute_item_count', store=True)
    # item_count_active = fields.Integer(string="Майна включено", compute='_compute_item_count', store=True)

    request_item_count = fields.Integer(string="Майна в запиті", compute='_compute_request_item_count', store=True)
    template_subject = fields.Text('Тема документа', compute='_compute_template_data', store=True)
    template_description = fields.Text('Текст документа', compute='_compute_template_data', store=True)
    template_suffix = fields.Text('Суфікс документа', compute='_compute_template_data', store=True)

    @api.onchange('subject_id')
    def _onchange_subject_id(self):
        for record in self:
            self.blocked_document_ids = False   

    # @api.onchange('stage_id')
    # def _onchange_state(self):
    #     for record in self:
    #         self.list_document_date = False

    @api.onchange('company_id')
    def _onchange_company_id(self):
        if self.company_id:
            asset_blocked_list_id = self.env['asset.blocked.list'].search([('company_id', '=', self.company_id.id)], limit=1)
            if asset_blocked_list_id.id:
                self.asset_blocked_list_id = asset_blocked_list_id
            else:
                msg = "Перелік майна {company_name} вісутній. Його необхідно створити".format(company_name=self.company_id.name)
                raise UserError(msg)

    # for report
    @api.depends('type_id', 'company_id', 'asset_blocked_list_id')
    def _compute_template_data(self):
        for item in self:
            if all([item.type_id, item.type_id.description, item.company_id, item.asset_blocked_list_id]):
                company_name = item.company_id.name
                # TODO: handle None/False values
                # change to mail_template?
                if item.type_code == 'approve':
                    list_document_date = False
                    list_document_no = False
                else:
                    if not item.asset_blocked_list_id.document_id:
                        msg = "В картці 'Перелік майна' необхідно вказати реквізити рішення про його затвердження".format(company_name=self.company_id.name)
                        raise UserError(msg)
                    list_document_date = item.asset_blocked_list_id.document_id.doc_date.strftime('%d.%m.%Y')
                    list_document_no = item.asset_blocked_list_id.document_id.doc_number

                template_text = item.type_id.description.format(company_name=company_name  or '', list_document_date=list_document_date  or '', list_document_no=list_document_no  or '')
                template = template_text.split('\n')
                item.template_subject = template[0]
                item.template_description = template[1].split('|')
                item.template_suffix = template[2]

# for report
    @api.depends('type_id', 'company_id', 'asset_blocked_list_id')
    def py3o_report_data(self):
        for item in self:
            if all([item.type_id, item.type_id.description, item.company_id, item.asset_blocked_list_id]):
                # TODO: handle None/False values
                # change to mail_template?
                if item.type_code == 'approve':
                    list_document_date = False
                    list_document_no = False
                else:
                    if not item.asset_blocked_list_id.document_id:
                        msg = "В картці 'Перелік майна' необхідно вказати реквізити рішення про його затвердження".format(company_name=self.company_id.name)
                        raise UserError(msg)
                    list_document_date = item.asset_blocked_list_id.document_id.doc_date.strftime('%d.%m.%Y')
                    list_document_no = item.asset_blocked_list_id.document_id.doc_number

                template = item.type_id.description.split('\n')
                company_name = item.company_id.name
                item.template_subject = template[0].format(company_name=company_name)
                item.template_description = template[1].format(company_name=company_name, list_document_date=list_document_date, list_document_no=list_document_no)
                item.template_suffix = template[2].format(company_name=company_name)

    # for report
    @api.depends('type_id', 'company_id', 'asset_blocked_list_id')
    def py3o_lines_layout(self):
        self.ensure_one()
        res = []
        company_name = self.company_id.name
        if all([self.type_id, self.type_id.description, self.company_id, self.asset_blocked_list_id]):
            # TODO: handle None/False values
            # change to mail_template?
            if self.type_code == 'approve':
                list_document_date = False
                list_document_no = False
            else:
                if not self.asset_blocked_list_id.document_id:
                    msg = "В картці 'Перелік майна' необхідно вказати реквізити рішення про його затвердження".format(company_name=self.company_id.name)
                    raise UserError(msg)
                list_document_date = self.asset_blocked_list_id.document_id.doc_date.strftime('%d.%m.%Y')
                list_document_no = self.asset_blocked_list_id.document_id.doc_number

            line_index = 1
            for line in self.type_id.child_ids:
                line_template = line.description.format(company_name=company_name  or '')
                # line_text = '{}. {}'.format(line_index, line_template)
                line_text = u'{}.\N{NO-BREAK SPACE}{}'.format(line_index, line_template)
                line_index += 1
                res.append({'line_text': line_text})

        return res

                # coord = {'latitude': '37.24N', 'longitude': '-115.81W'}
                # 'Coordinates: {latitude}, {longitude}'.format(**coord)
                # line_text = line_template.format(company_name=company_name, list_document_date=list_document_date, list_document_no=list_document_no)


    # for report
    @api.depends('document_text')
    def py3o_lines_text(self):
        self.ensure_one()
        res = []
        if self.document_text:
            lines = self.document_text.split('\n')
            line_index = 1
            for line in lines:
                res.append({'line_text': line})
        return res


    @api.depends('asset_blocked_ids', 'asset_blocked_exclude_ids')
    def _compute_request_item_count(self):
        for item in self:
            item.request_item_count = len(item.asset_blocked_ids)

    @api.model
    def _read_group_stage_ids(self, stages, domain, order):
        """ Read group customization in order to display all the stages in the
            kanban view, even if they are empty
        """
        domain = domain + [('res_model_id', '=', self.env.ref('dgf_asset_blocked.model_asset_blocked_request').id)]
        stage_ids = stages._search(domain, order=order, access_rights_uid=SUPERUSER_ID)
        return stages.browse(stage_ids)

    @api.depends('document_id', 'code', 'type_id')
    def _compute_name(self):
        for record in self:
            record.name = self._compose_name(record)

    @api.model
    def _compose_name(self, record):
        result = "[{0}] {1}".format(record.code, record.document_id.name)
        return result

    def set_request_to_item(self):
        self.ensure_one()
        self.asset_blocked_list_id.asset_blocked_ids.sudo().write({'request_id': self.id})

    def inprogress_request(self):
        stage_id = self.env['base.stage'].search([('code', '=', 'inprogress')], limit=1)
        self._change_state(stage_id)

    def approve_request(self):
        stage_id = self.env['base.stage'].search([('code', '=', 'approved')], limit=1)
        self.document_text = self._compute_doc_template_fields()
        self._change_state(stage_id)

    @api.depends('lang', 'resource_ref')
    def _compute_doc_template_fields(self):
        for record in self:
            if record.type_id.doc_template_id and record.id:
                document_text = record.type_id.doc_template_id._render_field('body', [record.id])[record.id]
            else:
                document_text = record.type_id.doc_template_id.body
            return document_text


    def _change_state(self, new_stage_id):
        for record in self:
            if new_stage_id.code == 'approved':
                if any([record.document_id.id is False, record.asset_blocked_list_id.id is False]):
                    msg = """Для зміни стану на "Затверджено" необхідно вказати значення полів: \n"Перелік майна"\n"Рішення про затвердження"."""
                    raise UserError(msg)
                else:
                    record.close_date = fields.Date.context_today(record)
                    record.stage_id = new_stage_id.id
                    items_model = record.asset_blocked_ids._name
                    items_exclude = record.asset_blocked_exclude_ids.mapped('asset_blocked_list_item_id')
                    if record.type_id.code == 'exclude':
                        items_exclude_stage_id = self.env['base.stage'].search(['&', ('code', '=', 'exclude'), ('res_model_id.model', '=', items_model)], limit=1)
                        record_id = record.id if isinstance(record.id, int) else record.ids[0]
                        items_exclude.sudo().write({'stage_id': items_exclude_stage_id.id, 'exclude_request_id': record_id})
                    elif record.type_id.code in ['include', 'approve']:
                        items_include_stage_id = self.env['base.stage'].search(['&', ('code', '=', 'include'), ('res_model_id.model', '=', items_model)], limit=1)
                        record.asset_blocked_ids.sudo().write({'stage_id': items_include_stage_id.id})
                        # update asset_blocked_list_id.document_id
                        if all([record.type_id.code == 'approve', record.asset_blocked_list_id.document_id.id is False]):
                            record.asset_blocked_list_id.document_id = record.document_id
            elif new_stage_id.code == 'inprogress':
                if record.type_id.code == 'exclude':
                    asset_blocked_list_item_ids = record.asset_blocked_exclude_ids.mapped('asset_blocked_list_item_id').ids
                    items_exclude = record.asset_blocked_exclude_ids.ids
                    if len(asset_blocked_list_item_ids) != len(items_exclude):
                        msg = """Для продовження необхідно співставити усі позиції майна в розділі "Майно"."""
                        raise UserError(msg)
                    elif len(items_exclude) == 0:
                        msg = """Для продовження необхідно додати майно в розділі "Майно"."""
                        raise UserError(msg)
                    else:
                        record.stage_id = new_stage_id
                else:
                    if len(record.asset_blocked_ids.ids) == 0:
                        msg = """Для продовження необхідно додати майно в розділі "Майно"."""
                        raise UserError(msg)
                    else:
                        record.stage_id = new_stage_id
            else:
                record.stage_id = new_stage_id

    def request_list_item_action(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Майно блоковане',
            'view_type': 'form',
            'view_mode': 'tree,form,pivot',
            'res_model': 'asset.blocked.list.item',
            'view_id': False,
            # 'view_id': self.env.ref('dgf_asset_blocked.dgf_asset_blocked_list_item_tree_base').id,
            # 'view_ids': [(5, 0, 0),
            #     (0, 0, {'view_mode': 'tree', 'view_id': self.env.ref('dgf_asset_blocked.dgf_asset_blocked_list_item_tree_base').id}),
            #     (0, 0, {'view_mode': 'form', 'view_id': self.env.ref('dgf_asset_blocked.dgf_asset_blocked_list_item_form').id})],
            'domain': [('request_id', '=', self.id)],
            'context': {
                'default_request_id': self.id,
                # 'search_default_include': 1,
                'default_asset_blocked_list_id': self.asset_blocked_list_id.id,
            },
        }

    def request_item_action(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Майно для викючення',
            'view_type': 'form',
            'view_mode': 'tree,form,pivot',
            'res_model': 'asset.blocked.request.item',
            'target': 'current',
            # 'domain': [('request_id', '=', self.id)],
            # 'domain': [('exclude_request_id', '=', self.id)],
            # 'context': {
            #     'default_request_id': self.id,
            # },
        }

    @api.model
    def create(self, vals):
        sequence = self.env.ref('dgf_asset_blocked.asset_blocked_request_sequence')
        if sequence:
            vals['code'] = sequence.next_by_id()
        return super().create(vals)

    def unlink(self):
        if self.user_has_groups('base.group_erp_manager'):
            return super().unlink()
        else:
            msg = """Заборонено видалення записів."""
            raise UserError(msg)


    def action_create_agreement(self):
        self.ensure_one()
        # lines = []
        # for item in self.asset_blocked_ids.ids:
        #     line = (0, 0, {'asset_id': item})
        #     lines.append(line)
        # print(lines)
        return {
            'name': 'Договори',
            'view_type': 'form',
            'res_model': 'asset.blocked.agreement',
            'view_id': False,
            'view_mode': 'form',
            # 'target': 'new',
            'context': {
                'default_request_ids': [self.id],
                'default_company_id': self.company_id.id,
                'default_subject_id': self.aquirer_id.id,
                'default_asset_blocked_ids': self.asset_blocked_ids.ids},
                # [(6, 0, request.ids)]
            'type': 'ir.actions.act_window'
        }

    def action_agreement_wizard(self):
        self.ensure_one()
        return {
            'name': 'Створення договору',
            'view_type': 'form',
            'res_model': 'wiz.request.agreement',
            'view_id': False,
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_request_id': self.id,
                'default_company_id': self.company_id.id,
                'default_subject_id': self.aquirer_id.id,
                'default_asset_blocked_ids': self.asset_blocked_ids.ids},
            'type': 'ir.actions.act_window'
        }


def action_create_lot(self):
        # selected_assets = self.ids
        active_ids = self.env.context.get('active_ids', [])
        lines = []
        for item in active_ids:
            line = (0, 0, {'asset_id': item})
            lines.append(line)
        # print('Records selected: {}'.format(len(active_ids)))
        return {
            'name': 'Лот',
            'view_type': 'form',
            'res_model': 'dgf.auction.lot',
            'view_id': False,
            'view_mode': 'form',
            # 'target': 'new',
            'context': {
                # 'default_parent_document_id': self.id,
                # 'default_category_id': self.category_id.id,
                # 'default_document_type_id': self.document_type_id.id,   # serch document_type_id
                # 'default_department_id': self.department_id.id,  # serch department_id
                # TODO: define the right way to add o2m values
                # 'default_asset_ids': [(0, 0, {'asset_id': 12283})]
                'default_asset_ids': lines
            },
            'type': 'ir.actions.act_window'
        }

    # py3o - _get_or_create_single_report
    # def button_validate(self):
    #     if any(statement.state != 'posted' or not statement.all_lines_reconciled for statement in self):
    #         raise UserError(_('All the account entries lines must be processed in order to validate the statement.'))

    #     for statement in self:

    #         # Chatter.
    #         statement.message_post(body=_('Statement %s confirmed.', statement.name))

    #         # Bank statement report.
    #         if statement.journal_id.type == 'bank':
    #             content, content_type = self.env.ref('account.action_report_account_statement')._render(statement.id)
    #             self.env['ir.attachment'].create({
    #                 'name': statement.name and _("Bank Statement %s.pdf", statement.name) or _("Bank Statement.pdf"),
    #                 'type': 'binary',
    #                 'datas': base64.encodebytes(content),
    #                 'res_model': statement._name,
    #                 'res_id': statement.id
    #             })

    #     self._check_balance_end_real_same_as_computed()
    #     self.write({'state': 'confirm', 'date_done': fields.Datetime.now()})

    # test
    # def action_get_attachment(self):
    #     """ This method is used to generate attachment for pdf report"""
    #     pdf = self.env.ref('module_name.report_id')._render_qweb_pdf(self.ids)
    #     b64_pdf = base64.b64encode(pdf[0])
    #     # save pdf as attachment
    #     name = "My Attachment"
    #     return self.env['ir.attachment'].create({
    #         'name': name,
    #         'type': 'binary',
    #         'datas': b64_pdf,
    #         'store_fname': name,
    #         'res_model': self._name,
    #         'res_id': self.id,
    #         'mimetype': 'application/x-pdf'
    #     })

    # def generate_report_file(self, id):
    #     pdf = self.env.ref('mymodule.action_report_labtest').render_qweb_pdf(id)[0]
    #     pdf = base64.b64encode(pdf)
    #     return pdf

    # def action_test(self):
    #     report_binary = self.generate_report_file(LabObj.id)
    #     attachmentObj = self.env['ir.attachment'].create({
    #         'name': attachment_name,
    #         'type': 'binary',
    #         'datas': report_binary,
    #         'datas_fname': attachment_name + '.pdf',
    #         'store_fname': attachment_name,
    #         'res_model': self._name,
    #         'res_id': self.id,
    #         'mimetype': 'application/x-pdf'
    #     })

    # sync asset_blocked_exclude_ids with asset_blocked_ids
    # def map_exclude_ids(self):
    #     for record in self:
    #         if record.type_id.code == 'exclude':
    #             if record.asset_blocked_ids:  # len(record.asset_blocked_ids) == len(items_exclude)
    #                 msg = "Активи в переліку вже ідентифіковано."
    #                 raise UserError(msg)
    #             else:
    #                 items_exclude = record.asset_blocked_exclude_ids.mapped('asset_blocked_list_item_id')
    #                 if items_exclude:
    #                     record.asset_blocked_ids = [(6, 0, items_exclude.ids)]
    #                 else:
    #                     msg = "Активи для виключення не імпоротовано."
    #                     raise UserError(msg)

    # @api.model
    # def _action_context(self):
    #     """
    #     Allows to use active_id & ref('xmlid') in action context in xml view, reffering this function
    #     """
    #     ref = self.env.ref
    #     active_id = unquote("active_id")

    #     return {
    #         'default_document_type_id': ref('dgf_document.decision').id,
    #         'default_department_id': ref('dgf_document.dep_kkupa').id,
    #         'default_parent_document_id': active_id,
    #     }

    # def archive_equipment_request(self):
    #     self.write({'archive': True})

    # def reset_equipment_request(self):
    #     """ Reinsert the maintenance request into the maintenance pipe in the first stage"""
    #     first_stage_obj = self.env['maintenance.stage'].search([], order="sequence asc", limit=1)
    #     # self.write({'active': True, 'stage_id': first_stage_obj.id})
    #     self.write({'archive': False, 'stage_id': first_stage_obj.id})

    # @api.onchange('company_id')
    # def _onchange_company_id(self):
    #     if self.company_id and self.maintenance_team_id:
    #         if self.maintenance_team_id.company_id and not self.maintenance_team_id.company_id.id == self.company_id.id:
    #             self.maintenance_team_id = False

    #     @api.depends('equipment_ids')
    #     def _compute_equipment(self):
    #         for team in self:
    #             team.equipment_count = len(team.equipment_ids)
