# Copyright 2016 LasLabs Inc.
# License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl.html).

from odoo import api, fields, models
from odoo.exceptions import ValidationError


class DgfBaseType(models.Model):
    _inherit = ['dgf.base.type']

    doc_template_id = fields.Many2one('doc.template', string='Шаблон', ondelete='cascade')  # index=True,
