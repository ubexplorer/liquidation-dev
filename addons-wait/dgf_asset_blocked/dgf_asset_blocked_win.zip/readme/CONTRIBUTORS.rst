* Alexis de Lattre <alexis.delattre@akretion.com>
* Yves Goldberg <yves@ygol.com>
* Alexandre Fayolle <alexandre.fayolle@camptocamp.com>
* `Tecnativa <https://www.tecnativa.com>`_:

    * Sergio Teruel

* Tharathip Chaweewongphan <tharathipc@ecosoft.co.th>
