* Florent Aide (`XCG Consulting <http://odoo.consulting/>`_)
* Laurent Mignon <laurent.mignon@acsone.eu>,
* Alexis de Lattre <alexis.delattre@akretion.com>,
* Guewen Baconnier <guewen.baconnier@camptocamp.com>
* Omar Castiñeira <omar@comunitea.com>
* Holger Brunn <hbrunn@therp.nl>
