# -*- coding: utf-8 -*-

from . import stat_classifier_katottg
from . import res_country_district
from . import res_country_ttg
from . import res_country_np
from . import res_country_np_district
from . import res_partner
from . import res_country
from . import address