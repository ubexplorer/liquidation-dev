Abstract module that provide base fonctionnality for implementing alternative provider for the IAP application.

An example of alternative provider can be found in the repository "connnector-telephony", with the module **sms_ovh_http** (sending sms with ovh instead of odoo iap)
