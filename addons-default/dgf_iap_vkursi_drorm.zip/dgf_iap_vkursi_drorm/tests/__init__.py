from . import test_dgf_iap_vkursi_contacts
