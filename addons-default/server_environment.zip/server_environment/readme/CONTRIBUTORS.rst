* Florent Xicluna (Wingo) <florent.xicluna@gmail.com>
* Nicolas Bessi <nicolas.bessi@camptocamp.com>
* Alexandre Fayolle <alexandre.fayolle@camptocamp.com>
* Daniel Reis <dgreis@sapo.pt>
* Holger Brunn <hbrunn@therp.nl>
* Leonardo Pistone <leonardo.pistone@camptocamp.com>
* Adrien Peiffer <adrien.peiffer@acsone.com>
* Thierry Ducrest <thierry.ducrest@camptocamp.com>
* Guewen Baconnier <guewen.baconnier@camptocamp.com>
* Thomas Binfeld <thomas.binsfeld@acsone.eu>
* Stéphane Bidoul <stefane.bidoul@acsone.com>
* Simone Orsi <simahawk@gmail.com>
