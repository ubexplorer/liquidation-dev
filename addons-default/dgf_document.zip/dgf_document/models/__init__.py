# -*- coding: utf-8 -*-

from . import dgf_document_category
from . import dgf_document_type
from . import dgf_document
from . import hr_department
from . import res_company
from . import res_partner
from . import mail_activity
# from . import dgf_res_partner_docs_rel
# from . import res_config_settings
