# [Install]
python\python.exe -m pip install --no-index --find-links=z-modules-py odoo_import_export_client

# [Configure]
python\python.exe python\Scripts\odoo_import_thread.py --help
import.conf

# [Use]
python\python.exe python\Scripts\odoo_import_thread.py -c import\import.conf --file=import\res.partner.csv --model=res.partner --worker=4 --size=2000

